package pe.edu.upc.controller;

import java.text.ParseException;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.support.SessionStatus;

import pe.edu.upc.entity.Administrador;
import pe.edu.upc.service.IAdministradorService;

@Controller
@RequestMapping("/administrador")
public class AdministradorController {

	@Autowired
	private IAdministradorService suService;

	@RequestMapping("/index")
	public String irWelcome() {
		return "welcome";
	}
	@Secured("ROLE_USER")
	@GetMapping("/new")
	public String newAdministrador(Model model) {
		model.addAttribute("administrador", new Administrador());
		return "administrador/administrador";
	}
	@Secured("ROLE_USER")
	@PostMapping("/save")
	public String saveAdministrador(@Valid Administrador administrador, BindingResult result, Model model, SessionStatus status)
			throws Exception {
		if (result.hasErrors()) {
			return "administrador/administrador";
		} else {
			int rpta = suService.insert(administrador);
			if (rpta > 0) {
				model.addAttribute("mensaje", "Ya existe");
				return "/administrador/administrador";
			} else {
				model.addAttribute("mensaje", "Se guardó correctamente");
				status.setComplete();
			}
			model.addAttribute("listAdministradores", suService.list());
			return "administrador/listAdministradores";
		}
	}
	@Secured("ROLE_USER")
	@RequestMapping("/delete")
	public String deleteAdministrador(Map<String, Object> model, @RequestParam(value = "id") Long id) {
		try {
			if (id != null && id > 0) {
				suService.delete(id);
				model.put("mensaje", "Se eliminó correctamente");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			model.put("mensaje", "No se pudo eliminar");
		}
		model.put("listAdministradores", suService.list());
		return "administrador/listAdministradores";
	}
	@Secured("ROLE_USER")
	@GetMapping("/list")
	public String listAdministradores(Model model) {
		try {
			model.addAttribute("administrador", new Administrador());
			model.addAttribute("listAdministradores", suService.list());
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
		}
		return "administrador/listAdministradores";
	}
	@Secured("ROLE_USER")
	@GetMapping("/listFind")
	public String listAdministradoresFind(Model model) {
		try {
			model.addAttribute("administrador", new Administrador());
			model.addAttribute("listAdministradores", suService.list());
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
		}
		return "administrador/find";
	}
	@Secured("ROLE_USER")
	@RequestMapping("/find")
	public String findByAdministrador(Map<String, Object> model, @ModelAttribute Administrador administrador) throws ParseException {
		List<Administrador> listAdministradores;
		administrador.setName(administrador.getName());
		listAdministradores = suService.findByName(administrador.getName());
		
		if (listAdministradores.isEmpty()) {
			model.put("mensaje", "No se encontró");
		}
		model.put("listAdministradores", listAdministradores);
		return "administrador/find";
	}
	@Secured("ROLE_USER")
	@GetMapping("/detail/{id}")
	public String detailsAdministrador(@PathVariable(value = "id") long id, Model model) {
		try {
			Optional<Administrador> administrador = suService.listarId(id);
			if (!administrador.isPresent()) {
				model.addAttribute("info", "El administrador no existe");
				return "redirect:/administrador/list";
			} else {
				model.addAttribute("administrador", administrador.get());
			}

		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
		}
		return "administrador/update";
	}
	@Secured("ROLE_USER")
	@PostMapping("/savemodify")
	public String saveAdministrador2(@Valid Administrador sup, BindingResult result, Model model, SessionStatus status)
			throws Exception {
		if (result.hasErrors()) {
			return "administrador/administrador";
		} else {
			suService.insertmodified(sup);

			model.addAttribute("mensaje", "Se modificó correctamente");
			model.addAttribute("listAdministradores", suService.list());
			status.setComplete();
			return "administrador/listAdministradores";
		}
	}
}