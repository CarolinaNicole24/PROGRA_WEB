package pe.edu.upc.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Entity
@Table(name = "Administrador")
public class Administrador {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long administradorID;

	@Size(min=1,max=50)
	@NotEmpty(message = "Ingrese el nombre del administrador")
	@Column(name = "name", nullable = false, length = 50)
	private String name;
	
	@Size(min=11,max=11)
	@NotEmpty(message = "Ingrese la identificacion del administrador")
	@Column(name = "iden", nullable = false, length = 11)
	private String iden;

	@Size(min=7,max=9)
	@NotEmpty(message = "Ingrese el teléfono del administrador")
	@Column(name = "phoneNumber", nullable = false, length = 9)
	private String phoneNumber;

	@Size(min=1,max=50)
	@NotEmpty(message = "Ingrese la dirección del administrador")
	@Column(name = "address", nullable = false, length = 50)
	private String address;

	public Long getAdministradorID() {
		return administradorID;
	}

	public void setAdministradorID(Long administradorID) {
		this.administradorID = administradorID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIdentificacion() {
		return iden;
	}

	public void setIdentificacion(String iden) {
		this.iden = iden;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
}
