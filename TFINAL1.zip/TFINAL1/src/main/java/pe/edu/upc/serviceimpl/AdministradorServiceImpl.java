package pe.edu.upc.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pe.edu.upc.entity.Administrador;
import pe.edu.upc.repository.IAdministradorRepository;
import pe.edu.upc.service.IAdministradorService;

@Service
public class AdministradorServiceImpl implements IAdministradorService {

	@Autowired
	private IAdministradorRepository suR;

	@Override
	@Transactional
	public Integer insert(Administrador administrador) {
		int rpta=suR.findAdministradorName(administrador.getName());
		if(rpta==0) {
			suR.save(administrador);
		}
		return rpta;
	}

	@Override
	@Transactional(readOnly=true)
	public List<Administrador> list() {
		return suR.findAll(Sort.by(Sort.Direction.DESC, "name"));
	}

	@Override
	public Optional<Administrador> listarId(long administradorID) {
		return suR.findById(administradorID);
	}

	@Override
	public List<Administrador> findByName(String Name) {
		return suR.findByName(Name);
	}



	@Override
	@Transactional
	public void delete(long administradorID) {
		suR.deleteById(administradorID);
	}

	@Override
	public void insertmodified(Administrador administrador) {
		suR.save(administrador);
	}
}

