package pe.edu.upc.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "Request")
public class Request {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long requestID;

	@Column(name = "CreationDate")
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date createAt;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "details_id",nullable=true)
	private List<Requirement_Detail> requiDetails;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "asesor_ID", nullable = false)
	private Asesor asesor;
	///// -------------------------------------------
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "type_OrderID", nullable = false)
	private Order_Type type_OrderID;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "accountingID", nullable = false)
	private Accounting accountingID;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "administradorID", nullable = false)
	private Administrador administradorID;

		
	
	
	
	public Administrador getAdministradorID() {
		return administradorID;
	}

	public void setAdministradorID(Administrador administradorID) {
		this.administradorID = administradorID;
	}

	public Long getRequestID() {
		return requestID;
	}

	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}

	public Date getCreateAt() {
		return createAt;
	}

	public void setCreateAt(Date createAt) {
		this.createAt = createAt;
	}

	public List<Requirement_Detail> getRequiDetails() {
		return requiDetails;
	}

	public void setRequiDetails(List<Requirement_Detail> requiDetails) {
		this.requiDetails = requiDetails;
	}

	public Asesor getAsesor() {
		return asesor;
	}

	public void setAsesor(Asesor asesor) {
		this.asesor = asesor;
	}

	public Order_Type getType_OrderID() {
		return type_OrderID;
	}

	public void setType_OrderID(Order_Type type_OrderID) {
		this.type_OrderID = type_OrderID;
	}

	public Accounting getAccountingID() {
		return accountingID;
	}

	public void setAccountingID(Accounting accountingID) {
		this.accountingID = accountingID;
	}

	public Request() {
		this.requiDetails = new ArrayList<>();
	}

	@PrePersist
	public void prePersist() {
		createAt = new Date();
	}

	public void setrequiDetails(List<Requirement_Detail> requiDetails) {
		this.requiDetails = requiDetails;
	}

	public void addrequiDetails(Requirement_Detail item) {
		this.requiDetails.add(item);
	}

	public double getTotal() {
		return requiDetails.stream().collect(Collectors.summingDouble(Requirement_Detail::calculateAmount));

	}

}
