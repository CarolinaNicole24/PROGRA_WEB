package pe.edu.upc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import pe.edu.upc.entity.Accounting;

@Repository
public interface IAccounting_OfficerRepository extends JpaRepository<Accounting, Long>
{
	@Query("select count(a.Placa) from Accounting a where a.Placa =:Placa")
	public int searchPlacaAccounting(@Param("Placa") String Placa);

	@Query("select a from Accounting a where a.Placa like %:Placa%")
	List<Accounting> findByPlaca(String Placa);
	
	@Query("select a from Accounting a")
	List<Accounting> findByListHello();

}
