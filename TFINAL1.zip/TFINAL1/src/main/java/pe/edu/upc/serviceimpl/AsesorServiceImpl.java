package pe.edu.upc.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pe.edu.upc.entity.Asesor;
import pe.edu.upc.repository.IAsesorRepository;
import pe.edu.upc.service.IAsesorService;

@Service
public class AsesorServiceImpl implements IAsesorService {

	@Autowired
	private IAsesorRepository sR;

	@Override
	@Transactional
	public Integer insert(Asesor asesor) {
		int rpta = sR.findAsesorName(asesor.getName());
		if (rpta == 0) {
			sR.save(asesor);
		}
		return rpta;
	}

	@Override
	@Transactional
	public void delete(long asesorID) {
		sR.deleteById(asesorID);

	}

	@Override
	@Transactional(readOnly = true)
	public List<Asesor> list() {
		return sR.findAll(Sort.by(Sort.Direction.DESC, "name"));
	}

	@Override
	public Optional<Asesor> listarAsesorID(long asesorID) {
		return sR.findById(asesorID);
	}

	@Override
	public List<Asesor> findByName(String name) {
		return sR.findByName(name);
	}

	@Override
	public Optional<Asesor> findById(Long idAsesor) {
		// TODO Auto-generated method stub
		return sR.findById(idAsesor);
	}

	@Override
	public Optional<Asesor> fetchByAsesorWithRequests(Long id) {
		// TODO Auto-generated method stub
		return sR.fetchByAsesorWithRequests(id);
	}

	@Override
	public void insertmodified(Asesor asesor) {
		sR.save(asesor);
		
	}

}	


