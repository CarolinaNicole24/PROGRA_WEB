package pe.edu.upc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import pe.edu.upc.entity.Administrador;

@Repository
public interface IAdministradorRepository extends JpaRepository<Administrador,Long> {
	@Query("select count(s.name) from Administrador s where s.name =:name")
	public int findAdministradorName(@Param("name") String administradorname);

	@Query("select s from Administrador s where s.name like %:name%")
	List<Administrador> findByName(String name);

	
}
