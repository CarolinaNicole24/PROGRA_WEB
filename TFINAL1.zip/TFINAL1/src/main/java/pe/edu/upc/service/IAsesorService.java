package pe.edu.upc.service;

import java.util.List;
import java.util.Optional;

import pe.edu.upc.entity.Asesor;


public interface IAsesorService {
	public Integer insert(Asesor asesor);

	public void delete(long asesorID);

	List<Asesor> list();

	Optional<Asesor> listarAsesorID(long asesorID);

	List<Asesor> findByName(String name);

	Optional<Asesor> findById(Long idAsesor);

	/////////////
	Optional<Asesor> fetchByAsesorWithRequests(Long id);
	public void insertmodified(Asesor asesor);

}
