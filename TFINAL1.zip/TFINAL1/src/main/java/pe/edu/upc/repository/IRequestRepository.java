package pe.edu.upc.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import pe.edu.upc.entity.Request;

@Repository
public interface IRequestRepository extends JpaRepository<Request, Long> {

	
	@Query("select o from Request o join fetch o.asesor c join fetch o.requiDetails od join fetch od.product where o.requestID=?1")
	Optional<Request> fetchByRequestrequestIDWithAsesorWhithRequirement_DetailWithProduct_Requirement(Long id);
	
	List<Request> findByCreateAt(Date fecha);

	@Query(value = "SELECT s.name, count(r.administradorid)from request r join administrador s on s.administradorid = r.administradorid group by s.name", nativeQuery = true)
	List<String[]> requestedAdministradores();

	@Query(value = "SELECT s.name, count(r.asesorID)from request r join asesor s on s.asesorID= r.asesorID group by s.name order by count(r.asesorID) desc limit 1", nativeQuery = true)
	List<String[]> requestedAsesores();
	
	@Query(value =  "SELECT a.Namex, count(r.accountingID) from request r join accounting a on a.Accounting_OfficerID = r.accountingID group by a.Namex order by count(r.accountingID) desc limit 1", nativeQuery = true)
	List<String[]> requestedAccounter();
	
}