package pe.edu.upc.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Entity
@Table(name = "accounting")
public class Accounting {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long AccountingOfficerID;

	@Size(min=1,max=50)
	@NotEmpty(message = "Ingrese el modelo del vehiculo")
	@Column(name = "Namex", nullable = false, length = 50)
	private String Namex;
	
	@Size(min = 8, max = 8)
	@NotEmpty(message = "Ingrese placa del vehiculo")
	@Column(name = "Placa", nullable = false, unique = true)
	private String Placa;

	public Long getAccountingOfficerID() {
		return AccountingOfficerID;
	}

	public void setAccountingOfficerID(Long accountingOfficerID) {
		AccountingOfficerID = accountingOfficerID;
	}

	public String getNamex() {
		return Namex;
	}

	public void setNamex(String namex) {
		Namex = namex;
	}

	public String getPlaca() {
		return Placa;
	}

	public void setPlaca(String placa) {
		Placa = placa;
	}

	public Accounting() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Accounting(Long accountingOfficerID,
			@NotEmpty(message = "Ingrese el modelo del vehiculo") String namex,
			@NotEmpty(message = "Ingrese placa del vehiculo") String placa) {

		super();
		AccountingOfficerID = accountingOfficerID;
		Namex = namex;
		Placa = placa;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((AccountingOfficerID == null) ? 0 : AccountingOfficerID.hashCode());
		result = prime * result + ((Placa == null) ? 0 : Placa.hashCode());
		result = prime * result + ((Namex == null) ? 0 : Namex.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Accounting other = (Accounting) obj;
		if (AccountingOfficerID == null) {
			if (other.AccountingOfficerID != null)
				return false;
		} else if (!AccountingOfficerID.equals(other.AccountingOfficerID))
			return false;
		if (Placa == null) {
			if (other.Placa != null)
				return false;
		} else if (!Placa.equals(other.Placa))
			return false;
		if (Namex == null) {
			if (other.Namex != null)
				return false;
		} else if (!Namex.equals(other.Namex))
			return false;
		return true;
	}

}
