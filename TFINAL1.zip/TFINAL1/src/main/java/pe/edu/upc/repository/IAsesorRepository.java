package pe.edu.upc.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import pe.edu.upc.entity.Asesor;


@Repository
public interface IAsesorRepository  extends JpaRepository<Asesor,Long>{
	@Query("select count(s.name) from Asesor s where s.name =:name")
	public int findAsesorName(@Param("name") String asesorname);

	@Query("select s from Asesor s where s.name like %:name%")
	List<Asesor> findByName(String name);


	////////////////////
	@Query("SELECT s FROM Asesor s LEFT JOIN FETCH s.requests o where s.supervisorID=?1")
	Optional<Asesor> fetchByAsesorWithRequests(Long id);
}
