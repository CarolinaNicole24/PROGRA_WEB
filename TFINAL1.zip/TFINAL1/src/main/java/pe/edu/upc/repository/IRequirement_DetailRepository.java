package pe.edu.upc.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import pe.edu.upc.entity.Requirement_Detail;

public interface IRequirement_DetailRepository extends JpaRepository<Requirement_Detail, Long>{


}
