package pe.edu.upc.service;

import java.util.List;
import java.util.Optional;

import pe.edu.upc.entity.Administrador;

public interface IAdministradorService {
	public Integer insert(Administrador administrador);

	public void delete(long administradorID);
	
	List<Administrador> list();

	Optional<Administrador> listarId(long administradorID);

	List<Administrador> findByName(String name);

	public void insertmodified(Administrador administrador);
	}

