package pe.edu.upc.controller;

import java.text.ParseException;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.support.SessionStatus;

import pe.edu.upc.entity.Asesor;

import pe.edu.upc.service.IAsesorService;

@Controller
@RequestMapping("/asesor")
public class AsesorController {
	@Autowired
	private IAsesorService sUService;

	@Secured("ROLE_USER")
	@GetMapping("/new")
	public String newAsesor(Model model) {
		model.addAttribute("asesor", new Asesor());
		return "asesor/asesor";
	}

	
	@PostMapping("/save")
	public String saveAsesor(@Valid Asesor Asesor, BindingResult result, Model model, SessionStatus status)
			throws Exception {
		if (result.hasErrors()) {
			return "asesor/asesor";
		} else {
			int rpta = sUService.insert(Asesor);
			if (rpta > 0) {
				model.addAttribute("mensaje", "Ya existe");
				return "/asesor/asesor";
			} else {
				model.addAttribute("mensaje", "Se guardó correctamente");
				status.setComplete();
			}
			model.addAttribute("listAsesores", sUService.list());
			return "asesor/listAsesores";
		}
	}

	@Secured("ROLE_USER")
	@RequestMapping("/delete")
	public String deleteAsesor(Map<String, Object> model, @RequestParam(value = "id") Long id) {
		try {
			if (id != null && id > 0) {
				sUService.delete(id);
				model.put("mensaje", "Se eliminó correctamente");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			model.put("mensaje", "No se pudo eliminar");
		}
		model.put("listAsesores", sUService.list());
		return "asesor/listAsesores";
	}

	@Secured("ROLE_USER")
	@GetMapping("/list")
	public String listAsesores(Model model) {
		try {
			model.addAttribute("asesor", new Asesor());
			model.addAttribute("listAsesores", sUService.list());
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
		}
		return "asesor/listAsesores";
	}
	@Secured("ROLE_USER")
	@GetMapping("/listWith")
	public String listAsesoresWithRequest(Model model) {
		try {
			model.addAttribute("asesor", new Asesor());
			model.addAttribute("listAsesores", sUService.list());
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
		}
		return "asesor/WithRequest";
	}
	
	
	@Secured("ROLE_USER")
	@GetMapping("/listFind")
	public String listAsesoresFind(Model model) {
		try {
			model.addAttribute("asesor", new Asesor());
			model.addAttribute("listAsesores", sUService.list());
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
		}
		return "asesor/find";
	}

	@Secured("ROLE_USER")
	@RequestMapping("/find")
	public String findByAsesor(Map<String, Object> model, @ModelAttribute Asesor asesor)
			throws ParseException {
		List<Asesor> listAsesores;
		asesor.setName(asesor.getName());
		listAsesores = sUService.findByName(asesor.getName());

		if (listAsesores.isEmpty()) {
			model.put("mensaje", "No se encontró");
		}
		model.put("listAsesores", listAsesores);
		return "asesor/find";
	}

	
	@Secured("ROLE_USER")
	@GetMapping("/detailrequest/{id}")
	public String detailsAsesor(@PathVariable(value = "id") Long id, Model model) {
		try {
			Optional<Asesor> asesor = sUService.findById(id);

			if (!asesor.isPresent()) {
				model.addAttribute("info", "Asesor no existe");
				return "redirect:/asesor/list";
			} else {
				model.addAttribute("asesor", asesor.get());
			}

		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
		}

		return "asesor/detailRequest";
	}
	
	@Secured("ROLE_USER")
	@GetMapping("/detail/{id}")
	public String detailsAsesor(@PathVariable(value = "id") long id, Model model) {
		try {
			Optional<Asesor> asesor = sUService.listarAsesorID(id);
			if (!asesor.isPresent()) {
				model.addAttribute("info", "El proveedor no existe");
				return "redirect:/asesor/list";
			} else {
				model.addAttribute("asesor", asesor.get());
			}

		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
		}
		return "asesor/update";
	}
	@Secured("ROLE_USER")
	@PostMapping("/savemodify")
	public String saveSupplier2(@Valid Asesor sup, BindingResult result, Model model, SessionStatus status)
			throws Exception {
		if (result.hasErrors()) {
			return "asesor/asesor";
		} else {
			sUService.insertmodified(sup);

			model.addAttribute("mensaje", "Se modificó correctamente");
			model.addAttribute("listAsesores", sUService.list());
			status.setComplete();
			return "asesor/listAsesores";
		}
	}

}
