package pe.edu.upc.controller;

import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import pe.edu.upc.entity.Request;
import pe.edu.upc.entity.Requirement_Detail;
import pe.edu.upc.entity.Asesor;
import pe.edu.upc.service.IAccounting_OfficerService;
import pe.edu.upc.service.IProduct_RequirementService;
import pe.edu.upc.service.IRequestService;
import pe.edu.upc.service.IAsesorService;
import pe.edu.upc.service.IAdministradorService;
import pe.edu.upc.service.ITypeorderService;

@Controller
@SessionAttributes("request")
@RequestMapping("/requests")
public class RequestController {
	@Autowired
	private IRequestService requestServ;
	@Autowired
	private IProduct_RequirementService proServ;
	@Autowired
	private IAsesorService asesorServ;
	@Autowired
	private ITypeorderService typeServ;
	@Autowired
	private IAccounting_OfficerService accServ;
	@Autowired
	private IAdministradorService administradorServ;

	// registro de request por asesor
	@GetMapping("/form/{id}")
	public String formRequest(@PathVariable(value = "id") Long id, Model model) {
		try {
			Optional<Asesor> sup = asesorServ.findById(id);
			if (!sup.isPresent()) {
				model.addAttribute("info", "Asesor no existe");
				return "redirect:/asesor/list";
			} else {
				Request a = new Request();
				a.setAsesor(sup.get());
				model.addAttribute("request", a);
				model.addAttribute("listAdministradores", administradorServ.list());
				model.addAttribute("listordertype", typeServ.list());
				model.addAttribute("listAccounting", accServ.list());

			}
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
		}
		return "request/form";
	}

	@PostMapping("/save")
	public String saveOrder(@Valid Request request, Model model, SessionStatus status, BindingResult binRes) {

		try {

			requestServ.insert(request);
			status.setComplete();
			model.addAttribute("mensaje", "Solicitud Generada");
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
			return "redirect:/request/form";
		}

		return "redirect:/supervisor/listWith";
	}

	// un view de toda la orden/como se veria la orden;
	@GetMapping("/detailproduct/{id}")
	public String detailRequest(@PathVariable(value = "id") Long id, Map<String, Object> model,
			RedirectAttributes flash) {

		Request req = requestServ.listarId(id);
		if (req == null) {
			flash.addFlashAttribute("error", "El detalle no existe.");
			return "redirect:/supervisor/listWith";
		}
		model.put("request", req);
		model.put("titulo", "Detalle de Solicitud Id:" + req.getRequestID());
		
		return "request/detail/detailsList";
		
	}
	
	@RequestMapping("/newproduct/{id}")
	public String reNewProduct(@PathVariable(value = "id") Long id, Map<String, Object> model) {

		model.put("detail", new Requirement_Detail());
		model.put("listproduct", proServ.list());

		Request obj = requestServ.listarId(id);
		model.put("request", obj);

		return "request/detail/detailsForm";
	}
	
	@PostMapping("/saveproduct{id}")
	public String newProductRequest(@PathVariable(value = "id") long id, @Valid Requirement_Detail reqdetail,RedirectAttributes flash,
			BindingResult result, Model model, SessionStatus status) {
		Request request = requestServ.listarId(id);
		if(result.hasErrors())
		{
			flash.addFlashAttribute("error","El valor debe ser positivo");
			String cadena1 = "redirect:/requests/newproduct/" + id;
			return cadena1;
		}
		try {
			request.addrequiDetails(reqdetail);
			requestServ.insert(request);
			status.isComplete();
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
			System.out.println(e.getMessage());
		}
		String cadena = "redirect:/requests/detailproduct/" + id;
		return cadena;
	}
	
	
	
	
	
	@GetMapping("/reportes")
	public String vistareportes(Map<String, Object> model) {
		
		return "request/reportes";
	}

	@GetMapping("/requestedAdministradores")
	public String listAllRequestedAdministradores(Map<String, Object> model) {
		model.put("requestedAdministradores", requestServ.listRequestedAdministradores());
		return "request/requestedAdministradores";
	}

	@GetMapping("/requestedAsesores")
	public String listAllRequestedAsesores(Map<String, Object> model) {
		model.put("requestedAsesores", requestServ.listRequestedAsesores());
		return "request/requestedAsesores";
	}

	@GetMapping("/requestAccounters")
	public String listAllRequestedAccounters(Map<String, Object> model) {
		model.put("requestedAccounters", requestServ.listRequestedAccounter());
		return "request/requestedAccounters";
	}
}
